window.onload = function () {
    var contentSection = document.getElementById('contentContainer');
    contentSection.style = "height: 700px; width: 1200px;";
    var subcontain = document.querySelector('#content_value > table');
    subcontain.style = "width: 100%";
    var contentSection = document.getElementById('map_big');
    contentSection.style = "width: 100%;";
    var c3 = document.querySelector('#map_whole > table');
    c3.style = "width: 600px;";
    /*var map_whole = document.getElementById('map_whole');
    map_whole.style = "width: 100%; height: 100%";
    map.style = "width: 600px;"
    var map_x_ref = document.getElementById('map_coord_y_wrap');
    map_x_ref.style = "height: 600px;";
    var map_x_ref = document.getElementById('map_coord_x_wrap');
    map_x_ref.style = "width: 600px;";*/
}
